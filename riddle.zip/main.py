import tkinter, random
from tkinter import messagebox

alreadypicked = []
def new_riddle() -> None:
  riddle_dict = {
    "What has a head and a tail, but no body?": "Coin",
    "What has a neck but no head?": "Shirt",
    "What has an eye but can't see?": "Needle",
    "What kind of band never plays music?": "Rubber Band"
  }
  riddleran = random.choice(list(riddle_dict))
  riddle = riddle_dict[riddleran]
  return riddleran, riddle
def password_check(chosen, password_entry) -> bool:
  global title
  password: str = password_entry.get().lower()
  if password == chosen.lower():
    messagebox.showinfo(title='Success', message='Password Correct')
    global riddleran, riddle
    while True:
      password_entry.delete(0, 'end')
      password_entry.insert(0, '')
      riddleran, riddle = new_riddle()
      if riddleran not in alreadypicked:
        break
    title.config(text=f"Guess the riddle:{riddleran}")
    return True
  else:
    messagebox.showerror(title='Try Again', message='PasswordIncorrect')
    return False
global riddleran, riddle 
root = tkinter.Tk()
riddleran, riddle = new_riddle()
alreadypicked.append(riddleran)
#Title
root.title("Riddle")
root.geometry("500x200")
global title
title = tkinter.Label(root, text=f"Guess the riddle:{riddleran}")
password_entry = tkinter.Entry(root, borderwidth=5)
submit = tkinter.Button(text='Guess', command=lambda: password_check(riddle, 
password_entry), width=25)
title.pack()
password_entry.pack(padx=10, pady=10)
submit.pack(pady=10)
root.mainloop()
